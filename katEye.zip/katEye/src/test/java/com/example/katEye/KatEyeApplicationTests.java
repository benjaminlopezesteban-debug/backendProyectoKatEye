package com.example.katEye;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KatEyeApplicationTests {

	@Test
	void contextLoads() {
	}

}
